﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Nancy.Hosting.Self;

namespace TestNancy
{
    class Program
    {
        static void Main(string[] args)
        {
            var uri = new Uri("http://localhost:8123/");
            var host = new NancyHost(uri);
            host.Start();
            Console.WriteLine("服务已启动");
            Console.ReadKey();

        }
    }
}
