﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Nancy;
using Nancy.ModelBinding;
using TestNancy.Entity;

namespace TestNancy.Controller
{
    public class Home : NancyModule
    {
        public Home()
            : base("/Home")
        {
            //拦截器
            Before += ctx =>
            {
                if (Request.Query.a != null)
                {
                    var res = new Response();
                    return res;
                }

                return null;
            };

            Get["/"] = _ =>
            {
                
                var a = Request.Query.name;
                //text/html;charset=UTF-8
                //text/plain;charset=UTF-8
                //text/json;charset=UTF-8
                return Response.AsText("我去会乱码吗aaa", "text/plain;charset=UTF-8");
            };

            Get["/Index"] = _ =>
            {

                var list = new List<string>() { "list1", "list2", "list3" };
                var model = new { list = list, a = "你好", b = "很不好", abc = "abc你好" };
                return View["Index.html", model];
            };

            Get["Test"] = _ =>
            {
                return View["Test.html"];
            };

            Get["Data"] = _ =>
            {
                var data = new { a = "你好", b = 1 };
                return Response.AsJson(data);
            };

            Post["Upload"] = _ =>
            {
                var uploadDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Content/Upload");
                if (!Directory.Exists(uploadDirectory))
                {
                    Directory.CreateDirectory(uploadDirectory);
                }
                var files = Request.Files;
                foreach (var file in files)
                {
                    var filename = Path.Combine(uploadDirectory, file.Name);
                    using (var fileStream = new FileStream(filename, FileMode.Create))
                    {
                        file.Value.CopyTo(fileStream);
                    }
                }
                return Response.AsText("ok");
            };

            Get["Cookie"] = _ =>
            {
                var res = new Response();
                res.ContentType = "text/plain;charset=UTF-8";
                res.Contents = stream =>
                {
                    var data = Encoding.UTF8.GetBytes("你好");
                    stream.Write(data, 0, data.Length);
                };
                return res.WithCookie("a", "45646");
            };

            Get["Abc"] = _ =>
            {
                DynamicDictionary dyDict = Request.Query;
                var dict = dyDict.ToDictionary();
                foreach (var key in dict.Keys)
                {
                    Console.WriteLine(key);
                    Console.WriteLine(dict[key]);
                    Console.WriteLine(dict[key].GetType());
                }
                return Response.AsText("111"); 
            };

            Get["Bind"] = _ =>
            {
                var p = this.Bind<People>();
                Console.WriteLine(p.Id);
                Console.WriteLine(p.Name);
                return Response.AsText("111");
            };

        }
    }
}
