﻿using System.Text;
using Nancy;
using Newtonsoft.Json;

namespace TestNancy
{
    public class JsonResponse : Response
    {
        public JsonResponse(object data)
        {
            ContentType = "text/plain;charset=UTF-8";
            Contents = stream =>
            {
                var bytes = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(data));
                stream.Write(bytes, 0, bytes.Length);
            };
        }
    }
}
