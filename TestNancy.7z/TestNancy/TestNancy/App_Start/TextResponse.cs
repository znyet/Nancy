﻿using System.Text;
using Nancy;
using Nancy.Responses;
using Newtonsoft.Json;

namespace TestNancy
{
    public class TextResponse : Response
    {
        public TextResponse(string text)
        {
            ContentType = "text/plain;charset=UTF-8";
            Contents = stream =>
            {
                var bytes = Encoding.UTF8.GetBytes(text);
                stream.Write(bytes, 0, bytes.Length);
            };
        }



    }
}
