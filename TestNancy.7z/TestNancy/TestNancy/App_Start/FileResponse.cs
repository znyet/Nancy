﻿using System.IO;
using Nancy;

namespace TestNancy
{
    public class FileResponse : Response
    {
        public FileResponse(byte[] body, string contentType = null)
        {
            ContentType = contentType ?? "application/octet-stream";
            Contents = stream =>
            {
                using (var writer = new BinaryWriter(stream))
                {
                    writer.Write(body);
                }
            };
        }
    }
}
